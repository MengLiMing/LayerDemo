//
//  ViewController.m
//  CATextLayer
//
//  Created by my on 2016/12/28.
//  Copyright © 2016年 my. All rights reserved.
//

#import "ViewController.h"
#import <CoreText/CoreText.h>

static CGFloat layer_width = 300;

@interface ViewController ()

@property (nonatomic, strong) CADisplayLink *displayLink;
@property (nonatomic, strong) CAShapeLayer *waterLayer;
@property (nonatomic, assign) CGFloat offx;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    _waterLayer = [CAShapeLayer layer];
    _waterLayer.fillColor = [UIColor redColor].CGColor;
    _waterLayer.strokeColor = [UIColor clearColor].CGColor;
    _displayLink = [CADisplayLink displayLinkWithTarget:self
                                               selector:@selector(waterMove)];
    [_displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
    
    //底部红色字体图层
    CATextLayer *text1 = [self attributeLayer:@"50%" width:layer_width textColor:[UIColor redColor]];
    text1.position = self.view.center;
    [self.view.layer addSublayer:text1];
    
    
    //文字和水波的图层
    CALayer *mainLayer = [CALayer layer];
    mainLayer.backgroundColor = [UIColor redColor].CGColor;
    mainLayer.bounds = CGRectMake(0, 0, layer_width, layer_width);
    mainLayer.position = self.view.center;
    mainLayer.mask = _waterLayer;
    
    CATextLayer *text2 = [self attributeLayer:@"50%" width:layer_width textColor:[UIColor whiteColor]];
    text2.position = [mainLayer convertPoint:self.view.center fromLayer:self.view.layer];
    [mainLayer addSublayer:text2];
    
    [self.view.layer addSublayer:mainLayer];
}


- (CATextLayer *)attributeLayer:(NSString *)str width:(CGFloat)width textColor:(UIColor *)color{
    CATextLayer *layer = [CATextLayer layer];
    //设置渲染的方式
    layer.contentsScale = [UIScreen mainScreen].scale;
    
    //如果没有设置其他样式的情况下，使用下边的代码能让我计算的高度准确一点
    //有办法计算高度准确的，请一定要联系我告诉我。。
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.lineSpacing = 1;
    
    //字体颜色
    NSMutableAttributedString *attributedStr = [[NSMutableAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:color,NSParagraphStyleAttributeName:paragraph}];
    //字体大小
    [attributedStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:30] range:NSMakeRange(0, str.length)];
    
    layer.string = attributedStr;
    //计算字体高度
    layer.bounds = [attributedStr boundingRectWithSize:CGSizeMake(width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading context:nil];
    //换行
    layer.wrapped = YES;
    //裁剪方式
    layer.truncationMode = kCATruncationEnd;
    //对齐
    layer.alignmentMode = kCAAlignmentNatural;
    return layer;
}


#pragma mark - 水波

- (UIBezierPath *)waterPathWithProgress:(CGFloat)progress offsetx:(CGFloat)offsetx{
    UIBezierPath *waterPath = [UIBezierPath bezierPath];
    CGFloat y;
    for (int i = 0; i <= layer_width; i ++) {
        y = 10 * sin(2*M_PI/layer_width * i + offsetx) + (1 - progress) * layer_width;
        if (i == 0) {
            [waterPath moveToPoint:CGPointMake(i, y)];
        } else {
            [waterPath addLineToPoint:CGPointMake(i, y)];
        }
    }
    [waterPath addLineToPoint:CGPointMake(layer_width, layer_width)];
    [waterPath addLineToPoint:CGPointMake(0, layer_width)];
    [waterPath closePath];
    return waterPath;
}



- (void)waterMove {
    //waterPath
    _offx += .1;
    _waterLayer.path = [self waterPathWithProgress:.5 offsetx:_offx].CGPath;
    
}



@end
