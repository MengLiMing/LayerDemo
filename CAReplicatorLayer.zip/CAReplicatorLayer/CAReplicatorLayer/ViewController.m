//
//  ViewController.m
//  CAReplicatorLayer
//
//  Created by my on 2017/1/9.
//  Copyright © 2017年 my. All rights reserved.
//

#import "ViewController.h"

#define SCREEN_WDITH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height

@interface ViewController ()
{
    CAGradientLayer *gradient;
}
@property (nonatomic, strong) CAReplicatorLayer *replicaLayer;


@property (nonatomic, strong) UILabel *textLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 9;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.selectionStyle = 0;
    cell.textLabel.text = [NSString stringWithFormat:@"动画%@",@(indexPath.row)];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_replicaLayer) {
        [_replicaLayer.sublayers makeObjectsPerformSelector:@selector(removeFromSuperlayer)];
        [_replicaLayer removeFromSuperlayer];
        _replicaLayer = nil;
    }
    //创建图层
    _replicaLayer = [CAReplicatorLayer layer];
    _replicaLayer.position = CGPointMake(SCREEN_WDITH/2, SCREEN_HEIGHT/2);
    _replicaLayer.backgroundColor = [UIColor groupTableViewBackgroundColor].CGColor;

    switch (indexPath.row) {
        case 0:
        {
            [self music];
        }
            break;
        case 1:
        {
            [self radar];
        }
            break;
        case 2:
        {
            [self animation2];
        }
            break;
        case 3:
        {
            [self animation3];
        }
            break;
        case 4:
        {
            [self animation4];
        }
            break;
        case 5:
        {
            [self animation4_1];
        }
            break;
        case 6:
        {
            [self animation6];
        }
            break;
        case 7:
        {
            [self animation7];
        }
            break;
        case 8:
        {
            [self animation8];
        }
            break;
        default:
            break;
    }
}


#pragma mark - 动画
- (void)music {
    NSInteger count = 6;
    CGFloat single_width = 15;
    CGFloat space = 5;
    CGFloat single_hegiht = 80;
    
    //2 设置属性
    //复制图层总数
    _replicaLayer.instanceCount = count;
    //设置相对于上一个图层的变换
    _replicaLayer.instanceTransform = CATransform3DMakeTranslation(single_width + space, 0, 0);
    //动画延迟
    _replicaLayer.instanceDelay = -.2;
    //设置复制颜色的偏移
    _replicaLayer.instanceGreenOffset = +.1;
    _replicaLayer.instanceRedOffset = -.1;
    _replicaLayer.instanceBlueOffset = +.15;
    _replicaLayer.instanceAlphaOffset = -.15;
    _replicaLayer.bounds = CGRectMake(0, 0, single_width * count + space * (count - 1), single_hegiht);
    
    //创建用于复制的图层
    CALayer *layer = [CALayer layer];
    layer.frame = CGRectMake(0, single_hegiht/2, single_width, single_hegiht);
    //需要设置
    layer.anchorPoint = CGPointMake(0.5, 1);
    layer.backgroundColor = [UIColor colorWithRed:.8 green:.3 blue:.1 alpha:1].CGColor;
    
    //创建动画
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.scale.y"];
    animation.toValue = @.1;
    animation.repeatCount = HUGE_VALF;
    animation.duration = .5;
    animation.autoreverses = YES;
    
    
    [layer addAnimation:animation forKey:nil];
    
    [_replicaLayer addSublayer:layer];
    [self.view.layer addSublayer:_replicaLayer];

}


#pragma mark - 雷达
- (void)radar {
    CGFloat radius_b = 100;
    CGFloat radius_s = 10;
    NSInteger count = 8;
    //复制的图层数
    _replicaLayer.instanceCount = count;
    _replicaLayer.instanceDelay = 2.0/count;
    _replicaLayer.bounds = CGRectMake(0, 0, 2*radius_b, 2*radius_b);

    //创建用于复制的图层
    CAShapeLayer *layer = [CAShapeLayer layer];
    layer.bounds = CGRectMake(0, 0, 2*radius_s, 2*radius_s);
    layer.path = [UIBezierPath bezierPathWithOvalInRect:layer.bounds].CGPath;
    layer.fillColor = [UIColor redColor].CGColor;
    layer.position = CGPointMake(100, 100);
    
    
    //透明
    CABasicAnimation *animation1 = [CABasicAnimation animationWithKeyPath:@"opacity"];
    animation1.toValue = @0.1;
    
    //放大
    CABasicAnimation *animation2 = [CABasicAnimation animationWithKeyPath:@"transform"];
    animation2.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(radius_b/radius_s, radius_b/radius_s, 1)];
    
    
    CAAnimationGroup *animationGroup = [CAAnimationGroup animation];
    animationGroup.duration = 2.0;
    animationGroup.repeatCount = HUGE_VALF;
    animationGroup.animations = @[animation1,animation2];
    
    [layer addAnimation:animationGroup forKey:nil];
    
    [_replicaLayer addSublayer:layer];
    [self.view.layer addSublayer:_replicaLayer];
}


#pragma mark - 2
- (void)animation2 {
    NSInteger count = 3;
    CGFloat radius = 10;
    CGFloat space = 5;
    
    
    
    _replicaLayer.instanceCount = count;
    _replicaLayer.bounds = CGRectMake(0, 0, 2*radius*count + space * (count - 1), 2*radius);
    _replicaLayer.instanceTransform = CATransform3DMakeTranslation(2*radius + space, 0, 0);
    _replicaLayer.instanceDelay = .3;
    
    //创建复制的图层
    CAShapeLayer *layer = [CAShapeLayer layer];
    layer.frame = CGRectMake(0, 0, 2*radius, 2*radius);
    layer.path = [UIBezierPath bezierPathWithOvalInRect:layer.bounds].CGPath;
    layer.fillColor = [UIColor redColor].CGColor;
    
    //缩小
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform"];
    animation.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(.2, .2, 1)];
    animation.repeatCount = HUGE_VALF;
    animation.duration = .6;
    animation.autoreverses = YES;
    
    [layer addAnimation:animation forKey:nil];
    
    [_replicaLayer addSublayer:layer];
    
    [self.view.layer addSublayer:_replicaLayer];
}


#pragma mark - 3(也可以实现动画2)
- (void)animation3 {
    NSInteger x_count = 3;
    NSInteger y_count = 3;
    CGFloat x_space = 5.0;
    CGFloat y_space = 5.0;
    
    CGFloat radius = 10;
    
    CGFloat width = x_count * 2 * radius + (x_count - 1) * x_space;
    CGFloat height = y_count * 2 * radius + (y_count - 1) * y_space;
    
    
    //创建用于复制的层
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.frame = CGRectMake(0, 0, 2*radius, 2*radius);
    shapeLayer.path = [UIBezierPath bezierPathWithOvalInRect:shapeLayer.bounds].CGPath;
    shapeLayer.fillColor = [UIColor redColor].CGColor;
    
    
    //透明
    CABasicAnimation *animation1 = [CABasicAnimation animationWithKeyPath:@"opacity"];
    animation1.toValue = @0.1;
    
    //缩小
    CABasicAnimation *animation2 = [CABasicAnimation animationWithKeyPath:@"transform"];
    animation2.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(.1, .1, 1)];
    
    CAAnimationGroup *animationGroup = [CAAnimationGroup animation];
    animationGroup.duration = 1;
    animationGroup.repeatCount = HUGE_VALF;
    animationGroup.animations = @[animation1,animation2];
    animationGroup.autoreverses = YES;
    [shapeLayer addAnimation:animationGroup forKey:nil];
    
    //横向复制一行
    CAReplicatorLayer *layer1 = [CAReplicatorLayer layer];
    layer1.frame = CGRectMake(0, 0, width, 2*radius);
    layer1.instanceCount = x_count;
    layer1.instanceDelay = -.2;
    layer1.instanceTransform = CATransform3DMakeTranslation(2*radius + x_space, 0, 0);
    [layer1 addSublayer:shapeLayer];



    //竖直复制
    _replicaLayer.instanceCount = y_count;
    _replicaLayer.bounds = CGRectMake(0, 0, width, height);
    _replicaLayer.instanceDelay = -.2;
    _replicaLayer.instanceTransform = CATransform3DMakeTranslation(0, 2*radius + y_space, 0);
    
    [_replicaLayer addSublayer:layer1];
    [self.view.layer addSublayer:_replicaLayer];
}

#pragma mark - 4
- (void)animation4 {
    NSInteger count = 10;

    //大圆的半径
    CGFloat radius_b = 40;
    //小圆
    CGFloat radius_s = 10;
    
    _replicaLayer.instanceCount = count;
    _replicaLayer.instanceDelay = -1.5/count;
    _replicaLayer.bounds = CGRectMake(0, 0, 2*radius_b, 2*radius_b);
    _replicaLayer.instanceTransform = CATransform3DMakeRotation((2*M_PI)/count, 0, 0, 1);
    
    
    //复制的图层
    CAShapeLayer *layer = [CAShapeLayer layer];
    layer.frame = CGRectMake(radius_b - radius_s, 0, 2*radius_s, 2*radius_s);
    layer.path = [UIBezierPath bezierPathWithOvalInRect:layer.bounds].CGPath;
    layer.fillColor = [UIColor redColor].CGColor;
    
    //动画
    //缩小
    CABasicAnimation *animation1 = [CABasicAnimation animationWithKeyPath:@"transform"];
    animation1.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(.1, .1, 1)];
    
    //透明
    CABasicAnimation *animation2 = [CABasicAnimation animationWithKeyPath:NSStringFromSelector(@selector(opacity))];
    animation2.toValue = @.1;
    
    //动画组
    CAAnimationGroup *animationGroup = [CAAnimationGroup animation];
    animationGroup.repeatCount = HUGE_VALF;
    animationGroup.duration = 1.5;
//    animationGroup.autoreverses = YES;
    animationGroup.animations = @[animation1,animation2];
    [layer addAnimation:animationGroup forKey:nil];
    
    [_replicaLayer addSublayer:layer];
    
    
    [self.view.layer addSublayer:_replicaLayer];
}

//动画4的另一种实现
- (void)animation4_1 {
    NSInteger count = 10;
    
    //大圆的半径
    CGFloat radius_b = 40;
    //小圆
    CGFloat radius_s = 10;
    
    _replicaLayer.instanceCount = count;
    _replicaLayer.instanceDelay = -1.5/count;
    _replicaLayer.bounds = CGRectMake(0, 0, 2*radius_b, 2*radius_b);
    
    
    //复制的图层
    CAShapeLayer *layer = [CAShapeLayer layer];
    layer.bounds = CGRectMake(0, 0, 2*radius_s, 2*radius_s);
    layer.position = CGPointMake(2*radius_b - radius_s, radius_b);
    layer.path = [UIBezierPath bezierPathWithOvalInRect:layer.bounds].CGPath;
    layer.fillColor = [UIColor redColor].CGColor;
    
    //动画
    CABasicAnimation *animation1 = [CABasicAnimation animationWithKeyPath:@"transform"];
    animation1.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(.1, .1, 1)];
    //透明
    CABasicAnimation *animation2 = [CABasicAnimation animationWithKeyPath:NSStringFromSelector(@selector(opacity))];
    animation2.toValue = @.1;
    
    CAKeyframeAnimation *animation3 = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    animation3.path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(radius_b, radius_b) radius:radius_b - radius_s startAngle:0 endAngle:2*M_PI clockwise:NO].CGPath;
    animation3.rotationMode = kCAAnimationRotateAuto;
    
    
    //动画组
    CAAnimationGroup *animationGroup = [CAAnimationGroup animation];
    animationGroup.repeatCount = HUGE_VALF;
    animationGroup.duration = 1.5;
    animationGroup.animations = @[animation1,animation2,animation3];
    [layer addAnimation:animationGroup forKey:nil];
    
    [_replicaLayer addSublayer:layer];
    [self.view.layer addSublayer:_replicaLayer];
}


#pragma mark - 6
- (void)animation6 {
    NSInteger count = 3;
    
    //旋转的路径圆
    CGFloat radius_b = 40;
    //子layer的半径
    CGFloat radius_s = 10;

    
    _replicaLayer.instanceCount = count;
    _replicaLayer.bounds = CGRectMake(0, 0, 2*radius_b, 2*radius_b);
    _replicaLayer.instanceTransform  = CATransform3DMakeRotation(2*M_PI/count, 0, 0, 1);
    
    //复制layer
    CAShapeLayer *layer = [CAShapeLayer layer];
    layer.fillColor = [UIColor redColor].CGColor;
    layer.frame = CGRectMake(radius_b - radius_s, 0, radius_s * 2, radius_s * 2);
    
    //注释代码是x方向上的移动，希望能帮助对动画过程的理解
    //x方向上移动
//    layer.frame = CGRectMake( 0, radius_b - radius_s, radius_s * 2, radius_s * 2);

    layer.path = [UIBezierPath bezierPathWithOvalInRect:layer.bounds].CGPath;
    
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform"];
    CATransform3D toValue = CATransform3DIdentity;

    toValue = CATransform3DTranslate(toValue, 0, radius_b - radius_s, 0);
    toValue = CATransform3DRotate(toValue, 2*M_PI/count, 0, 0, 1);
    toValue = CATransform3DTranslate(toValue, 0, - (radius_b - radius_s), 0);
    
    //x方向移动
    //    toValue = CATransform3DTranslate(toValue, radius_b - radius_s, 0, 0);
    //    toValue = CATransform3DRotate(toValue, 2*M_PI/count, 0, 0, 1);
    //    toValue = CATransform3DTranslate(toValue, - (radius_b - radius_s), 0, 0);
    
    animation.toValue = [NSValue valueWithCATransform3D:toValue];
    animation.repeatCount = HUGE_VALF;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.duration = 1;

    [layer addAnimation:animation forKey:nil];

    
    [_replicaLayer addSublayer:layer];
    [self.view.layer addSublayer:_replicaLayer];
}


#pragma mark - 7 //实现一个倒影吧
- (void)animation7 {
    //创建复制层
    UIImage *image = [UIImage imageNamed:@"myicon"];
    
    CALayer *layer = [CALayer layer];
    layer.frame = CGRectMake(0, 0, 150, 150);
    layer.contents = (__bridge id)image.CGImage;
    layer.contentsGravity = kCAGravityResizeAspectFill;
    
    
    _replicaLayer.instanceCount = 2;
    CATransform3D trans = CATransform3DIdentity;
    trans = CATransform3DTranslate(trans, 0, 2, 0);
    trans = CATransform3DRotate(trans, M_PI, 1, 0, 0);
    _replicaLayer.instanceTransform  = trans;
    _replicaLayer.instanceAlphaOffset = -0.6;
    _replicaLayer.bounds = CGRectMake(0, 0, 150, 302);

    
    //对比上方代码，旋转的变换的中心是_replicaLayer的中心
//    _replicaLayer.instanceCount = 2;
//    CATransform3D trans = CATransform3DIdentity;
//    trans = CATransform3DTranslate(trans, 0, 150 + 2, 0);
//    trans = CATransform3DRotate(trans, M_PI, 1, 0, 0);
//    _replicaLayer.instanceTransform  = trans;
//    _replicaLayer.instanceAlphaOffset = -0.6;
//    _replicaLayer.bounds = CGRectMake(0, 0, 150, 150);
    
    
    [_replicaLayer addSublayer:layer];
    [self.view.layer addSublayer:_replicaLayer];
    
}

#pragma mark - animation8
- (void)animation8 {
    
    //创建复制层
    if (!gradient) {
        gradient = [CAGradientLayer layer];
        gradient.startPoint = CGPointMake(0, .5);
        gradient.endPoint = CGPointMake(1, .5);
        gradient.colors = @[
                            (id)[UIColor blackColor].CGColor,
                            (id)[UIColor whiteColor].CGColor,
                            (id)[UIColor blackColor].CGColor
                            ];
        gradient.locations = @[@0.25,@0.5,@0.75];
        
        gradient.frame = CGRectMake(0, 0, SCREEN_WDITH, 40);
        
        
        CATextLayer *text = [CATextLayer layer];
        text.contentsScale = [UIScreen mainScreen].scale;
        NSString *str = @"走得慢，还好没停下走得慢";
        NSMutableAttributedString *attributedStr = [[NSMutableAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:[UIColor blackColor]}];
        [attributedStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:30] range:NSMakeRange(0, str.length)];
        text.string = attributedStr;
        CGFloat height = [attributedStr boundingRectWithSize:CGSizeMake(SCREEN_WDITH, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading context:nil].size.height;
        text.frame = CGRectMake(0, 0, SCREEN_WDITH, height);
        text.alignmentMode = kCAAlignmentCenter;
        gradient.mask = text;
    }
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"locations"];
    animation.fromValue = @[@0, @0, @0.25];
    animation.toValue = @[@0.75, @1, @1];
    animation.duration = 2.5;
    animation.repeatCount = HUGE_VALF;
    [gradient addAnimation:animation forKey:@"LocationAnimation"];
    
    _replicaLayer.instanceCount = 2;
    CATransform3D trans = CATransform3DIdentity;
    trans = CATransform3DTranslate(trans, 0, 40 + 2, 0);
    trans = CATransform3DRotate(trans, M_PI, 1, 0, 0);
    _replicaLayer.instanceTransform  = trans;
    _replicaLayer.instanceAlphaOffset = -0.8;
    _replicaLayer.bounds = CGRectMake(0, 0, SCREEN_WDITH, 40);
    
    [_replicaLayer addSublayer:gradient];
    [self.view.layer addSublayer:_replicaLayer];
}

@end
