//
//  AppDelegate.h
//  CAReplicatorLayer
//
//  Created by my on 2017/1/9.
//  Copyright © 2017年 my. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

