//
//  ViewController.m
//  CATransformLayer
//
//  Created by my on 2016/12/28.
//  Copyright © 2016年 my. All rights reserved.
//

#import "ViewController.h"

static CGFloat contain_width = 200;
static CGFloat sub_width = 100;

#define DEGREE(d) ((d) * M_PI/180.0)
@interface ViewController ()

@property (nonatomic, strong) CALayer *container1;
@property (nonatomic, strong) CATransformLayer *container2;
@property (nonatomic, strong) CADisplayLink *displayLink;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    //两种容器完全相同的设置
    _container1 = [self cubeLayerWithClass:NSStringFromClass([CALayer class])];
    _container2 = [self cubeLayerWithClass:NSStringFromClass([CATransformLayer class])];
    
    [self setContainer:_container1];
    [self setContainer:_container2];
    
    
    _container1.position = CGPointMake(self.view.center.x, self.view.center.y - contain_width/2 - 10);
    _container2.position = CGPointMake(self.view.center.x, self.view.center.y + contain_width/2 + 10);
    
    [self.view.layer addSublayer:_container1];
    [self.view.layer addSublayer:_container2];

    //定时器
    _displayLink = [CADisplayLink displayLinkWithTarget:self
                                               selector:@selector(rotationAnimation)];
    [_displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
}

- (void)setContainer:(CALayer *)container {
    container.backgroundColor = [UIColor groupTableViewBackgroundColor].CGColor;
    container.bounds = CGRectMake(0, 0, contain_width, contain_width);

    //作用于子视图，为了更好地观察效果
    CATransform3D subTransfrom = CATransform3DIdentity;
    subTransfrom.m34 = -1/500;
    subTransfrom = CATransform3DRotate(subTransfrom, M_PI/9, 1, 0, 0);
    subTransfrom = CATransform3DRotate(subTransfrom, M_PI/9, 0, 1, 0);
    container.sublayerTransform = subTransfrom;
}

//动起来
- (void)rotationAnimation {
    [self addAimationToLayer:_container1];
    [self addAimationToLayer:_container2];
}


- (id)cubeLayerWithClass:(NSString *)classStr {
    CALayer *cube = [NSClassFromString(classStr) layer];
    
    CATransform3D transfrom;
    
    //面1
    transfrom = CATransform3DMakeTranslation(0, 0, sub_width/2);
    [cube addSublayer:[self layerWithTransform:transfrom]];
    
    //面2
    transfrom = CATransform3DMakeTranslation(0, 0, -sub_width/2);
    [cube addSublayer:[self layerWithTransform:transfrom]];
    
    //面3
    transfrom = CATransform3DMakeTranslation(sub_width/2, 0, 0);
    transfrom = CATransform3DRotate(transfrom, M_PI_2, 0, 1, 0);
    [cube addSublayer:[self layerWithTransform:transfrom]];
    
    //面4
    transfrom = CATransform3DMakeTranslation(-sub_width/2, 0, 0);
    transfrom = CATransform3DRotate(transfrom, -M_PI_2, 0, 1, 0);
    [cube addSublayer:[self layerWithTransform:transfrom]];
    
    
    //面5
    transfrom = CATransform3DMakeTranslation(0, sub_width/2, 0);
    transfrom = CATransform3DRotate(transfrom, M_PI_2, 1, 0, 0);
    [cube addSublayer:[self layerWithTransform:transfrom]];

    //面6
    transfrom = CATransform3DMakeTranslation(0, -sub_width/2, 0);
    transfrom = CATransform3DRotate(transfrom, -M_PI_2, 1, 0, 0);
    [cube addSublayer:[self layerWithTransform:transfrom]];
    
    return cube;
}



- (CALayer *)layerWithTransform:(CATransform3D)transform {
    CALayer *layer = [CALayer layer];
    layer.bounds = CGRectMake(0, 0, sub_width, sub_width);
    layer.position = CGPointMake(contain_width/2, contain_width/2);
    CGFloat red = arc4random()%255/255.0;
    CGFloat green = arc4random()%255/255.0;
    CGFloat blue = arc4random()%255/255.0;
    
    layer.backgroundColor = [UIColor colorWithRed:red
                                            green:green
                                             blue:blue
                                            alpha:1].CGColor;
    layer.transform = transform;
    return layer;
}


- (void)addAimationToLayer:(CALayer *)layer {
    static float degree = 0.f;
    
    CGFloat duration = 1.f;
    CGFloat singleDuration = 1 / (duration * 60.0);
    CGFloat singleDegree = 45/(duration * 60.0);
    
    
    CATransform3D fromValue = CATransform3DIdentity;
    fromValue.m34 = -1/500;
    fromValue = CATransform3DRotate(fromValue, DEGREE(degree), 0, 1, 0);
    
    CATransform3D toValue = CATransform3DIdentity;
    toValue.m34 = -1/500;
    toValue = CATransform3DRotate(toValue, DEGREE(degree += singleDegree), 0, 1, 0);
    
    //使用transform无法实现旋转2*M_PI，此时可以使用虚拟属性@"transform.rotation.y",可以使用相对值旋转byValue
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform"];
    animation.duration = singleDuration;
    animation.fromValue = [NSValue valueWithCATransform3D:fromValue];
    animation.toValue = [NSValue valueWithCATransform3D:toValue];
    animation.repeatCount = HUGE_VALL;
    animation.removedOnCompletion = NO;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    [layer addAnimation:animation forKey:@"transform"];
}

@end
