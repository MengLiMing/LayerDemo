//
//  ViewController.m
//  CAShapeLayer
//
//  Created by my on 2016/12/27.
//  Copyright © 2016年 my. All rights reserved.
//

#import "ViewController.h"
#import <CoreText/CoreText.h>

@interface ViewController ()


@property (nonatomic, strong) UIView *waterView;
@property (nonatomic, strong) CADisplayLink *displayLink;
@property (nonatomic, strong) CAShapeLayer *waterLayer;
@property (nonatomic, assign) CGFloat offx;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.waterView];

    _waterLayer = [CAShapeLayer layer];
    [self.waterView.layer addSublayer:_waterLayer];
    
    _waterLayer.strokeStart = -1;
    _waterLayer.strokeEnd = 0;
    _waterLayer.fillColor = [UIColor redColor].CGColor;
    _waterLayer.strokeColor = [UIColor greenColor].CGColor;
    _waterLayer.lineCap = kCALineJoinBevel;
    _waterLayer.lineDashPattern = @[@8,@8];
    _waterLayer.lineWidth = 5;

    _displayLink = [CADisplayLink displayLinkWithTarget:self
                                               selector:@selector(waterMove)];
    [_displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
}


- (UIBezierPath *)waterPathWithProgress:(CGFloat)progress offsetx:(CGFloat)offsetx{
    UIBezierPath *waterPath = [UIBezierPath bezierPath];
    CGFloat y;
    for (int i = 0; i <= _waterView.frame.size.width; i ++) {
        y = 10 * sin(2*M_PI/_waterView.frame.size.width * i + offsetx) + (1 - progress) * _waterView.frame.size.height;
        if (i == 0) {
            [waterPath moveToPoint:CGPointMake(i, y)];
        } else {
            [waterPath addLineToPoint:CGPointMake(i, y)];
        }
    }
    [waterPath addLineToPoint:CGPointMake(_waterView.frame.size.width, _waterView.frame.size.height)];
    [waterPath addLineToPoint:CGPointMake(0, _waterView.frame.size.height)];
    [waterPath closePath];
    return waterPath;
}



- (void)waterMove {
    //waterPath
    _offx += .1;
    
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    if (_waterLayer.strokeStart > 1) {
        _waterLayer.strokeStart = -1;
    }
    
    if (_waterLayer.strokeEnd > 1) {
        _waterLayer.strokeEnd = 0;
    }
    _waterLayer.strokeStart += 0.005*2;
    _waterLayer.strokeEnd += 0.005;
    
    [CATransaction commit];
    
    _waterLayer.path = [self waterPathWithProgress:.5 offsetx:_offx].CGPath;
    

}



- (UIView *)waterView {
    if (!_waterView) {
        _waterView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 200, 200)];
        _waterView.center = self.view.center;
    }
    return _waterView;
}

@end
